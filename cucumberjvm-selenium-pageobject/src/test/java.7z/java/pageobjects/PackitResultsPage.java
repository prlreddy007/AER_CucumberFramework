package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class PackitResultsPage extends BaseClass{

	public PackitResultsPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(how=How.XPATH, using=" (//div[@class='packit-result-item-fare-type']/a/span[1]/img)[1]")
	public static WebElement fareRules_iconFirstFare;
	
	@FindBy(how=How.XPATH, using=" //div[@class='packit-result-item-fare-type']/a/span[1]/img")
	public static WebElement fareRulesClose_icon;
	
	@FindBy(how=How.XPATH, using="(//div[@class='packit-flight-row-expanded-view-button']/a/span)[1]")
	public static WebElement flightRow_expandButton;
	
	@FindBy(how=How.XPATH, using="\r\n" + 
			"(//div[@class='packit-filter-item-buttons']/div/div[1]/a/span)[1]")
	public static WebElement bookNow_button;
	

}
