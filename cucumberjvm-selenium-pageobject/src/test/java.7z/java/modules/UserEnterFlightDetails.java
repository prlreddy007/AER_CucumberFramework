package modules;
import helpers.Log;
import java.util.HashMap;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import pageobjects.AutomationHomePage;
import pageobjects.PackitSearchPage;
import pageobjects.LoginPage;

public class UserEnterFlightDetails {
	public static void Execute(WebDriver driver,List<HashMap<String,String>> map) throws Exception{
		PackitSearchPage.from_origin.sendKeys(map.get(0).get("Origin"));
		PackitSearchPage.to_destination.sendKeys(map.get(0).get("Destination"));
		PackitSearchPage.date_of_travel.sendKeys(map.get(0).get("Departure date"));
		
		PackitSearchPage.return_date_of_travel.sendKeys(map.get(0).get("Arrival date"));
		PackitSearchPage.flights_search_button.click();;
		
		
		

	}
}
