package modules;
import helpers.Log;
import java.util.HashMap;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import pageobjects.AutomationHomePage;
import pageobjects.PackitSearchPage;
import pageobjects.LoginPage;
public class FlightResultsDisplay {
	public static void Execute(WebDriver driver,List<HashMap<String,String>> map) throws Exception{
		if(PackitSearchPage.modal_dialog.isDisplayed()) {
			Reporter.log("Modal dialog is opened");
			Assert.assertTrue("Modal dialog is displayed", true);


		}else{
			Assert.assertTrue("Modal dialog is not  displayed", false);

			Reporter.log("Modal dialog is not  opened");

		}
		Thread.sleep(35000);
		if(PackitSearchPage.flights_display_message.getText().contains("tyhrty")) {
			Assert.assertTrue("Results page is displayed", true);

			Reporter.log("Flight Results are displayed");

		}else {
			Assert.assertTrue("Results page is not  displayed", false);

			Reporter.log("Flight Results are not  displayed");

		}
	}
}
