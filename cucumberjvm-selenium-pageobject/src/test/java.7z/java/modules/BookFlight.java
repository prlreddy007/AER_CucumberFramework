package modules;

import java.util.concurrent.TimeUnit;
import pageobjects.BaseClass;
import pageobjects.PackitResultsPage;

public class BookFlight {
	public static void flightBooking() {
	BaseClass. driver.manage().timeouts().implicitlyWait(1800, TimeUnit.SECONDS);
		PackitResultsPage.fareRules_iconFirstFare.click();
		PackitResultsPage.fareRulesClose_icon.click();
		PackitResultsPage.flightRow_expandButton.click();
		PackitResultsPage.bookNow_button.click();
	}

}
