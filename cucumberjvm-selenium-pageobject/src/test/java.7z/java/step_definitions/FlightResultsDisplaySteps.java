package step_definitions;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import helpers.DataHelper;
import junit.framework.Assert;
import modules.FlightResultsDisplay;
import modules.SignInAction;
import modules.UserEnterFlightDetails;
import pageobjects.AutomationHomePage;
import pageobjects.LoginPage;
import pageobjects.PackitSearchPage;
import pageobjects.ShippingAddressPage;

public class FlightResultsDisplaySteps {

	public WebDriver driver;
    public List<HashMap<String,String>> datamap;


    public FlightResultsDisplaySteps()
    {
        driver = Hooks.driver;
        datamap = DataHelper.data();
    }

    @When("^I open packit website$")
    public void i_open_packit_website() throws Throwable {
        
    	driver.get("https://packit-qa.aerticket-it.de/");
    }
    
  
	@And("^I sign in and verify navigation to results page$")
	public void iSignInAndVerifyNavigationToResultsPage() throws Throwable {
		PageFactory.initElements(driver, LoginPage.class);
		PageFactory.initElements(driver, PackitSearchPage.class);
		SignInAction.Execute(driver, datamap);
	}

	@And("^I provide origin,destination and return of travel and submit$")
	public void iProvideOriginDestinationAndReturnOfTravelAndSubmit() throws Throwable {
		UserEnterFlightDetails.Execute(driver, datamap);
	}

	@Then("^I verify results page$")
	public void iVerifyResultsPage() throws Throwable {
    	FlightResultsDisplay.Execute(driver, datamap);
	}

	@And("^i click on button$")
	public void iClickOnButton() throws Throwable {
		
	AutomationHomePage.contact_us.click();
	
	PackitSearchPage.flights_display_message.sendKeys("");

	}







    
   
    
}
